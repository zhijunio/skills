package com.example.portal;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;

@Configuration(proxyBeanMethods = false)
@EnableWebSecurity
class PortalSecurity {
	@Bean
	SecurityFilterChain security(HttpSecurity http) {
		return http.authorizeHttpRequests(requests -> requests
						.requestMatchers("/api/csrf", "/login").permitAll()
						.requestMatchers("/api/documents/**", "/api/preferences").hasRole("EDITOR")
						.anyRequest().denyAll())
				.exceptionHandling(errors -> errors
						.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)))
				.formLogin(Customizer.withDefaults())
				.build();
	}

	@Bean
	UserDetailsService users() {
		var password = PasswordEncoderFactories.createDelegatingPasswordEncoder().encode("demo-password");
		return new InMemoryUserDetailsManager(
				User.withUsername("alice").password(password).roles("EDITOR").build(),
				User.withUsername("bob").password(password).roles("EDITOR").build());
	}
}
