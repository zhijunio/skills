package com.example.portal;

import java.security.Principal;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.http.HttpStatus;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
class PortalController {
	private final Map<Long, Document> documents = new ConcurrentHashMap<>(Map.of(
			1L, new Document("alice", "Alice draft"),
			2L, new Document("bob", "Bob draft")));
	private final Map<String, String> preferences = new ConcurrentHashMap<>();

	@GetMapping("/api/csrf")
	Map<String, String> csrf(CsrfToken csrf) {
		return Map.of("token", csrf.getToken(), "headerName", csrf.getHeaderName());
	}

	@GetMapping("/api/documents/{id}")
	Title document(@PathVariable long id, Principal caller) {
		return new Title(ownedDocument(id, caller).title());
	}

	@PatchMapping("/api/documents/{id}")
	Title rename(@PathVariable long id, @RequestBody Title title, Principal caller) {
		var document = ownedDocument(id, caller);
		documents.put(id, new Document(document.owner(), title.title()));
		return title;
	}

	@GetMapping("/api/preferences")
	Theme preference(Principal caller) {
		return new Theme(preferences.getOrDefault(caller.getName(), "light"));
	}

	@PatchMapping("/api/preferences")
	Theme changePreference(@RequestBody Theme theme, Principal caller) {
		preferences.put(caller.getName(), theme.theme());
		return theme;
	}

	private Document ownedDocument(long id, Principal caller) {
		var document = documents.get(id);
		if (document == null || !document.owner().equals(caller.getName())) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}
		return document;
	}

	record Title(String title) {}
	record Theme(String theme) {}
	private record Document(String owner, String title) {}
}
