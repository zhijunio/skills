# Orders API example

This sample uses one Spring Boot application. The `order` feature has an MVC controller, an application service, and a persistence package. Flyway creates the table in PostgreSQL. The API supports `POST /orders` and `GET /orders/{id}`.

From this directory, run `./mvnw -B test` for the MVC and architecture tests. Run `./mvnw -B verify` with Docker to include the PostgreSQL integration test.

To try the service in a shell, export a local `DATABASE_PASSWORD`, run `docker compose up -d`, then run `./mvnw spring-boot:run`. With the server running, send this request.

```bash
curl -i http://localhost:8080/orders \
  -H 'Content-Type: application/json' \
  --data '{"orderNumber":"MV-001"}'
```

The first request returns `201 Created` and a `Location` header. Use that URL to read the order. Sending the same request again returns `409 Conflict` with `application/problem+json`. A blank order number returns `400 Bad Request`.

- [Order controller](src/main/java/com/example/orders/order/OrderController.java) shows request validation and HTTP responses.
- [Order service](src/main/java/com/example/orders/order/OrderService.java) shows the transaction and constraint translation.
- [Architecture test](src/test/java/com/example/orders/architecture/OrderArchitectureTest.java) checks the production packages and a deliberate violation.
- [HTTP integration test](src/test/java/com/example/orders/OrderHttpIT.java) verifies creation, read-back, and duplicate handling with PostgreSQL.
