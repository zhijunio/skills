package com.example.orders.order;

import java.util.Optional;

import com.example.orders.order.persistence.OrderEntity;
import com.example.orders.order.persistence.OrderRepository;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderService {

	private final OrderRepository orders;

	public OrderService(OrderRepository orders) {
		this.orders = orders;
	}

	@Transactional
	public OrderResult create(String orderNumber) {
		try {
			return toResult(orders.saveAndFlush(new OrderEntity(orderNumber)));
		}
		catch (DataIntegrityViolationException exception) {
			for (Throwable cause = exception.getCause(); cause != null; cause = cause.getCause()) {
				if (cause instanceof ConstraintViolationException violation
						&& "uk_orders_order_number".equals(violation.getConstraintName())) {
					throw new DuplicateOrderNumberException(exception);
				}
			}
			throw exception;
		}
	}

	@Transactional(readOnly = true)
	public Optional<OrderResult> find(long id) {
		return orders.findById(id).map(OrderService::toResult);
	}

	private static OrderResult toResult(OrderEntity order) {
		return new OrderResult(order.id(), order.orderNumber());
	}

	public record OrderResult(long id, String orderNumber) {}

	static class DuplicateOrderNumberException extends RuntimeException {

		DuplicateOrderNumberException(Throwable cause) {
			super("Order number already exists", cause);
		}
	}
}
