package com.example.orders.order.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "orders")
public class OrderEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "order_number", nullable = false, length = 40)
	private String orderNumber;

	protected OrderEntity() {}

	public OrderEntity(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Long id() {
		return id;
	}

	public String orderNumber() {
		return orderNumber;
	}
}
