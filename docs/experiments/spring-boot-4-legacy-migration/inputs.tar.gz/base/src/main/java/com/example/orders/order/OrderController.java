package com.example.orders.order;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping("/orders")
class OrderController {

	private final OrderService orders;

	OrderController(OrderService orders) {
		this.orders = orders;
	}

	@PostMapping
	ResponseEntity<OrderResponse> create(@Valid @RequestBody CreateOrderRequest request) {
		var order = orders.create(request.orderNumber());
		var location = ServletUriComponentsBuilder.fromCurrentRequestUri()
				.path("/{id}").buildAndExpand(order.id()).toUri();
		return ResponseEntity.created(location).body(OrderResponse.from(order));
	}

	@GetMapping("/{id}")
	ResponseEntity<OrderResponse> find(@PathVariable long id) {
		return ResponseEntity.of(orders.find(id).map(OrderResponse::from));
	}

	@ExceptionHandler(OrderService.DuplicateOrderNumberException.class)
	ProblemDetail duplicateOrderNumber() {
		return ProblemDetail.forStatusAndDetail(HttpStatus.CONFLICT, "Order number already exists");
	}

	record CreateOrderRequest(@NotBlank @Size(max = 40) String orderNumber) {}

	record OrderResponse(long id, String orderNumber) {

		static OrderResponse from(OrderService.OrderResult result) {
			return new OrderResponse(result.id(), result.orderNumber());
		}
	}
}
