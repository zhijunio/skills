package com.example.orders.authorization;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import jakarta.servlet.Filter;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.test.context.junit.jupiter.web.SpringJUnitWebConfig;
import org.springframework.test.web.servlet.request.RequestPostProcessor;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringJUnitWebConfig(SecurityFilterChainTest.TestConfig.class)
class SecurityFilterChainTest {

	@Test
	void authenticatesRequestsAndEnforcesTheConfiguredRole(
			@Autowired WebApplicationContext context,
			@Autowired @Qualifier("springSecurityFilterChain") Filter securityFilter) throws Exception {
		var mvc = MockMvcBuilders.webAppContextSetup(context).addFilters(securityFilter).build();

		mvc.perform(get("/order-reports")).andExpect(status().isUnauthorized())
				.andExpect(header().exists("WWW-Authenticate"));
		mvc.perform(get("/order-reports").with(credentials("reader"))).andExpect(status().isForbidden());
		mvc.perform(get("/order-reports").with(credentials("reporter"))).andExpect(status().isOk())
				.andExpect(content().string("order reports"));
	}

	private static RequestPostProcessor credentials(String username) {
		String encoded = Base64.getEncoder().encodeToString((username + ":example-password")
				.getBytes(StandardCharsets.UTF_8));
		return request -> {
			request.addHeader("Authorization", "Basic " + encoded);
			return request;
		};
	}

	@Configuration(proxyBeanMethods = false)
	@EnableWebMvc
	@EnableWebSecurity
	static class TestConfig {

		@Bean
		SecurityFilterChain security(HttpSecurity http) {
			return http.authorizeHttpRequests(requests -> requests
					.requestMatchers("/order-reports").hasRole("REPORTER")
					.anyRequest().denyAll())
					.httpBasic(Customizer.withDefaults())
					.build();
		}

		@Bean
		UserDetailsService users() {
			String encoded = PasswordEncoderFactories.createDelegatingPasswordEncoder().encode("example-password");
			return new InMemoryUserDetailsManager(
					User.withUsername("reader").password(encoded).roles("READER").build(),
					User.withUsername("reporter").password(encoded).roles("REPORTER").build());
		}

		@Bean
		ReportController reportController() {
			return new ReportController();
		}
	}

	@RestController
	static class ReportController {

		@GetMapping("/order-reports")
		String report() {
			return "order reports";
		}
	}
}
