package com.example.orders.authorization;

import java.security.Principal;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class ResourceAuthorizationTest {

	@Test
	void editorCanArchiveOwnRecordButCannotChangeAnotherEditorsRecord() throws Exception {
		var documents = new Documents();
		documents.records.put(1L, new Document("alice", false));
		var mvc = MockMvcBuilders.standaloneSetup(new DocumentController(documents)).build();

		mvc.perform(post("/documents/{id}/archive", 1L).principal(() -> "bob")
				.with(request -> {
					request.addUserRole("EDITOR");
					return request;
				}))
				.andExpect(status().isNotFound());
		assertThat(documents.records.get(1L)).isEqualTo(new Document("alice", false));

		mvc.perform(post("/documents/{id}/archive", 1L).principal(() -> "alice")
				.with(request -> {
					request.addUserRole("EDITOR");
					return request;
				}))
				.andExpect(status().isNoContent());
		assertThat(documents.records.get(1L)).isEqualTo(new Document("alice", true));
	}

	@RestController
	static class DocumentController {
		private final Documents documents;

		DocumentController(Documents documents) {
			this.documents = documents;
		}

		@PostMapping("/documents/{id}/archive")
		@ResponseStatus(HttpStatus.NO_CONTENT)
		void archive(@PathVariable long id, Principal caller, HttpServletRequest request) {
			if (caller == null) {
				throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
			}
			if (!request.isUserInRole("EDITOR")) {
				throw new ResponseStatusException(HttpStatus.FORBIDDEN);
			}
			if (!documents.archiveIfOwned(id, caller.getName())) {
				throw new ResponseStatusException(HttpStatus.NOT_FOUND);
			}
		}
	}

	static class Documents {
		private final Map<Long, Document> records = new HashMap<>();

		boolean archiveIfOwned(long id, String owner) {
			var document = records.get(id);
			if (document == null || !document.owner().equals(owner)) {
				return false;
			}
			records.put(id, new Document(owner, true));
			return true;
		}
	}

	record Document(String owner, boolean archived) {}
}
