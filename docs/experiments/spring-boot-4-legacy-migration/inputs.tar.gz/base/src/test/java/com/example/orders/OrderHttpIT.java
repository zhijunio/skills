package com.example.orders;

import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Import(TestcontainersConfiguration.class)
class OrderHttpIT {

	@Autowired
	MockMvc mvc;

	@Test
	void createsAnOrderAndRejectsASecondWriteWithTheSameNumber() throws Exception {
		String orderNumber = UUID.randomUUID().toString();
		String request = "{\"orderNumber\":\"" + orderNumber + "\"}";
		String location = mvc.perform(post("/orders").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.orderNumber").value(orderNumber))
				.andReturn().getResponse().getHeader(HttpHeaders.LOCATION);

		mvc.perform(get(location))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.orderNumber").value(orderNumber));

		mvc.perform(post("/orders").contentType(MediaType.APPLICATION_JSON).content(request))
				.andExpect(status().isConflict())
				.andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
				.andExpect(jsonPath("$.detail").value("Order number already exists"));
	}
}
