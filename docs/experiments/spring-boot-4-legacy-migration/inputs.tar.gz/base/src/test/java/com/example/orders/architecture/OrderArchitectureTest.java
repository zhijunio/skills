package com.example.orders.architecture;

import com.example.orders.OrdersApplication;
import com.example.orders.inventory.InventoryDependencies;
import com.example.orders.order.persistence.OrderRepository;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.lang.ArchRule;
import org.junit.jupiter.api.Test;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;
import static org.assertj.core.api.Assertions.assertThat;

class OrderArchitectureTest {

	private static final ArchRule ORDER_PERSISTENCE_IS_PRIVATE = noClasses()
			.that().resideOutsideOfPackage("..order..")
			.should().dependOnClassesThat().resideInAPackage("..order.persistence..");

	@Test
	void productionCodeRespectsOrderBoundaries() {
		var code = new ClassFileImporter().withImportOption(ImportOption.Predefined.DO_NOT_INCLUDE_TESTS)
				.importPackagesOf(OrdersApplication.class);
		ORDER_PERSISTENCE_IS_PRIVATE.check(code);
		noClasses().that().haveSimpleNameEndingWith("Controller")
				.should().dependOnClassesThat().resideInAPackage("..persistence..").check(code);
	}

	@Test
	void publicServiceAccessPassesAndRepositoryAccessFails() {
		var importer = new ClassFileImporter();
		ORDER_PERSISTENCE_IS_PRIVATE.check(importer.importClasses(
				OrderRepository.class, InventoryDependencies.PublicServiceAccess.class));

		var violation = ORDER_PERSISTENCE_IS_PRIVATE.evaluate(importer.importClasses(
				OrderRepository.class, InventoryDependencies.RepositoryAccess.class));
		assertThat(violation.hasViolation()).isTrue();
		assertThat(violation.getFailureReport().toString()).contains("RepositoryAccess", "OrderRepository");
	}

	@Test
	void transitiveRuleFindsRepositoryThroughIntermediary() {
		var classes = new ClassFileImporter().importClasses(OrderRepository.class,
				InventoryDependencies.IndirectRepositoryAccess.class, InventoryDependencies.RepositoryAccess.class);
		var callers = noClasses().that().haveSimpleName("IndirectRepositoryAccess");
		callers.should().dependOnClassesThat().resideInAPackage("..order.persistence..").check(classes);

		var violation = callers.should().transitivelyDependOnClassesThat()
				.resideInAPackage("..order.persistence..").evaluate(classes);
		assertThat(violation.hasViolation()).isTrue();
		assertThat(violation.getFailureReport().toString()).contains("IndirectRepositoryAccess", "OrderRepository");
	}
}
