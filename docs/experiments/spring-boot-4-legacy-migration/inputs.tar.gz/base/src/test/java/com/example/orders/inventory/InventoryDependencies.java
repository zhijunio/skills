package com.example.orders.inventory;

import com.example.orders.order.OrderService;
import com.example.orders.order.persistence.OrderRepository;

public final class InventoryDependencies {

	public static class PublicServiceAccess {
		public Object find(OrderService orders) {
			return orders.find(1L);
		}
	}

	public static class RepositoryAccess {
		public Object find(OrderRepository orders) {
			return orders.findById(1L);
		}
	}

	public static class IndirectRepositoryAccess {
		public RepositoryAccess intermediary() {
			return new RepositoryAccess();
		}
	}
}
