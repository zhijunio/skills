package com.example.orders.order;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.verifyNoInteractions;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(OrderController.class)
class OrderControllerTest {

	@Autowired
	MockMvc mvc;
	@MockitoBean
	OrderService orders;

	@Test
	void rejectsBlankOrderNumberBeforeCallingService() throws Exception {
		mvc.perform(post("/orders").contentType(MediaType.APPLICATION_JSON)
				.content("""
						{"orderNumber":" "}
						"""))
				.andExpect(status().isBadRequest());
		verifyNoInteractions(orders);
	}
}
