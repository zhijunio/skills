import { execFileSync } from 'node:child_process'
import { access, chmod, mkdir, mkdtemp, readFile, readdir, rename, rmdir, rm, writeFile } from 'node:fs/promises'
import { basename, dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { parseArgs } from 'node:util'

const skill = fileURLToPath(new URL('../', import.meta.url))
const options = {
  name: { type: 'string' },
  'group-id': { type: 'string' },
  'output-dir': { type: 'string' },
  persistence: { type: 'string', default: 'none' },
  help: { type: 'boolean', short: 'h' },
}
const javaReservedWords = new Set((
  'abstract assert boolean break byte case catch char class const continue default do double else enum extends ' +
  'false final finally float for goto if implements import instanceof int interface long native new null package ' +
  'private protected public return short static strictfp super switch synchronized this throw throws transient ' +
  'true try void volatile while'
).split(' '))

function unzip(...args) {
  return execFileSync('unzip', args, { timeout: 10_000, maxBuffer: 2 * 1024 * 1024 })
}

async function extractArchive(zip, stage) {
  const entries = unzip('-Z1', zip).toString('utf8').trimEnd().split('\n')
  if (entries.length > 200 || new Set(entries).size !== entries.length) {
    throw new Error('Unexpected ZIP entry count or duplicate entries')
  }
  for (const entry of entries) {
    const parts = entry.replace(/\/$/, '').split('/')
    if (parts.some(part => !/^[a-zA-Z0-9._-]+$/.test(part) || ['.', '..'].includes(part))) {
      throw new Error(`Unsafe ZIP entry: ${JSON.stringify(entry)}`)
    }
    if (entry.endsWith('/')) continue
    const destination = join(stage, ...parts)
    await mkdir(dirname(destination), { recursive: true })
    // Write regular files, even if the ZIP contains Unix symlink metadata.
    await writeFile(destination, unzip('-p', zip, entry), { flag: 'wx' })
  }
}

async function createProject(values) {
  const { name, persistence } = values
  const group = values['group-id']
  if (!/^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/.test(name ?? '')) {
    throw new Error('--name must be a lowercase Maven artifact name such as orders-api')
  }
  if (!/^[a-z][a-z0-9]*(?:\.[a-z][a-z0-9]*)+$/.test(group ?? '')) {
    throw new Error('--group-id must use lowercase Java package segments such as com.example')
  }
  const packageName = `${group}.${name.replaceAll('-', '')}`
  if (packageName.split('.').some(segment => javaReservedWords.has(segment))) {
    throw new Error(`Java package cannot use a reserved word: ${packageName}`)
  }
  if (!values['output-dir']) throw new Error('--output-dir is required')
  if (!['none', 'jpa-postgresql'].includes(persistence)) {
    throw new Error('--persistence must be none or jpa-postgresql')
  }

  const output = resolve(values['output-dir'])
  const parent = dirname(output)
  if ((await readdir(parent)).includes(basename(output))) {
    throw new Error(`Output already exists: ${output}`)
  }
  const version = JSON.parse(await readFile(join(skill, 'versions.json'), 'utf8'))
  const database = persistence === 'jpa-postgresql'
  const dependencies = ['web', 'validation']
  if (database) dependencies.push('data-jpa', 'postgresql', 'flyway', 'testcontainers')
  const url = new URL('https://start.spring.io/starter.zip')
  url.search = new URLSearchParams({
    type: 'maven-project', bootVersion: version.springBoot, javaVersion: String(version.java),
    groupId: group, artifactId: name, name, packageName, dependencies: dependencies.join(','),
  }).toString()

  const work = await mkdtemp(join(parent, '.spring-boot-4-'))
  let reserved = false
  try {
    const archive = join(work, 'starter.zip')
    const stage = join(work, 'project')
    const here = await fetch(url, { signal: AbortSignal.timeout(30_000) })
    if (!here.ok) throw new Error(`Spring Initializr returned HTTP ${here.status}`)
    const chunks = []
    let bytes = 0
    for await (const chunk of here.body) {
      bytes += chunk.length
      if (bytes > 2 * 1024 * 1024) throw new Error('Spring Initializr archive exceeds 2 MiB')
      chunks.push(chunk)
    }
    await writeFile(archive, Buffer.concat(chunks))
    await extractArchive(archive, stage)
    await access(join(stage, '.mvn/wrapper/maven-wrapper.properties'))
    await chmod(join(stage, 'mvnw'), 0o755)
    const pom = await readFile(join(stage, 'pom.xml'), 'utf8')
    if (!pom.includes(`<version>${version.springBoot}</version>`) || !pom.includes(`<java.version>${version.java}</java.version>`)) {
      throw new Error('Spring Initializr returned an unexpected Boot or Java version')
    }
    const source = join(stage, 'src/main/java', ...packageName.split('.'))
    if (!(await readdir(source)).some(file => file.endsWith('Application.java'))) {
      throw new Error('Spring Initializr archive is missing its application class')
    }
    if (database) {
      const template = await readFile(join(skill, 'assets/templates/compose.yaml'), 'utf8')
      await writeFile(join(stage, 'compose.yaml'), template.replaceAll('{{POSTGRES_IMAGE}}', version.postgresImage), { flag: 'wx' })
      const properties = join(stage, 'src/main/resources/application.properties')
      await writeFile(properties, `\nspring.datasource.url=\${DATABASE_URL:jdbc:postgresql://localhost:5432/app}\nspring.datasource.username=\${DATABASE_USER:app}\nspring.datasource.password=\${DATABASE_PASSWORD}\nspring.jpa.hibernate.ddl-auto=validate\nspring.jpa.open-in-view=false\n`, { flag: 'a' })
      const testSource = join(stage, 'src/test/java', ...packageName.split('.'), 'TestcontainersConfiguration.java')
      const config = await readFile(testSource, 'utf8')
      const pinned = config.replace(/("postgres:)[^"\n]+"/, `"${version.postgresImage}"`)
      if (!pinned.includes(`"${version.postgresImage}"`)) throw new Error('Could not configure the PostgreSQL test image')
      await writeFile(testSource, pinned)
      // A service connection supplies the password. The placeholder is only used at runtime.
    }
    await mkdir(output)
    reserved = true
    await rename(stage, output)
    reserved = false
    console.log(output)
  } catch (error) {
    if (reserved) await rmdir(output)
    throw error
  } finally {
    await rm(work, { recursive: true, force: true })
  }
}

try {
  const { values } = parseArgs({ options })
  if (values.help) {
    console.log('Usage: node scripts/create-project.mjs --name orders-api --group-id com.example --output-dir /path/to/new-directory [--persistence none|jpa-postgresql]')
  } else {
    await createProject(values)
  }
} catch (error) {
  console.error(error.message)
  process.exitCode = 1
}
