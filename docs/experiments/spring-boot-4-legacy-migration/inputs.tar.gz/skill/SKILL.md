---
name: spring-boot-4
description: Scaffold a Spring Boot 4 service or implement and test application features in an existing Boot 4 project. Use for MVC endpoints, validation, JPA persistence, application authorization, and code organization or dependency constraints in the application.
---

# Spring Boot 4 project development

## Create a service

Read [bootstrap](references/bootstrap.md) for the generator, runtime requirements, and verification commands. Use the requested project identity and destination. Start with MVC and validation. Add PostgreSQL and JPA when the task requires relational storage. Read [architecture](references/architecture.md) when adding the first feature package.

## Modify an existing service

1. Read project instructions and inspect the build files and wrapper. Identify the Spring Boot release, Java toolchain, build tool, target module, and the closest existing feature and tests.
2. Check which API behavior, database constraints, authorization rules, and code dependencies the change must preserve. Follow the user's request and the project's rules. Use the adjacent feature as the implementation example. Use skill defaults for choices the project leaves open.
3. Read the references that match the change. Keep the project's selected web and persistence stacks when extending an existing feature.
4. Verify the changed behavior and the contracts it must preserve with the project wrapper and its existing checks. If the change affects stored data, verify the upgrade with representative existing records. Report the results and identify checks that could not run.

## References by task

- **Packages, module interfaces, or dependency checks.** Read [architecture](references/architecture.md).
- **MVC endpoints, DTOs, validation, or error responses.** Read [web MVC](references/web-mvc.md).
- **JPA mappings, schema migrations, transactions, or concurrent writes.** Read [JPA and PostgreSQL](references/data-jpa.md).
- **Authentication context or request and data authorization.** Read [application security](references/security.md).
- **Choosing or running application tests.** Read [testing](references/testing.md).

[Order example](assets/order-example/README.md) links to the runnable sample for a feature with MVC, JPA, PostgreSQL, and executable dependency constraints.
