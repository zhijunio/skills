# Implement Spring MVC endpoints

## Check the existing HTTP contract

Before changing an endpoint, inspect its callers, contract tests, and nearby controllers. Preserve request and response fields, validation, status codes, error format, and pagination or sorting defaults unless the task changes them.

## Keep HTTP handling at the boundary

Bind and validate input with a request DTO. Let the controller call an application service and map its result to a response DTO. Put business decisions and writes in the application operation. Enforce business rules there when callers can enter through paths other than HTTP.

If the project uses value objects for identifiers, follow its HTTP conversion convention for path and query parameters. Verify malformed values through MVC using the project's error format.

**Prefer.** Declare the accepted input and public output separately. The order controller accepts a validated `CreateOrderRequest`, calls the service, and returns an `OrderResponse`. [Runnable controller](../assets/order-example/src/main/java/com/example/orders/order/OrderController.java)

**Avoid.** A controller method such as `OrderEntity create(@RequestBody OrderEntity order)` couples accepted input and public output to persistence fields. Mapping changes can alter the API.

**Verify.** Exercise valid and invalid input through MVC. Assert the status and public JSON fields. Use the project's architecture checks to verify that controllers reach persistence through the application service.

## Translate known errors consistently

Use the project's existing exception handlers and error format. For a new API without a convention, use Spring's `ProblemDetail` for structured errors.

**Prefer.** Map a specific business failure to its established status and response. The order example maps a duplicate order number to `409 Conflict` through a typed exception handler. [Runnable controller](../assets/order-example/src/main/java/com/example/orders/order/OrderController.java)

**Avoid.** An `@ExceptionHandler(Exception.class)` that always returns `400 Bad Request` makes unexpected server failures indistinguishable from invalid input.

**Verify.** Assert status, content type, and stable error fields for the relevant invalid input, missing resource, or business conflict cases. [MVC slice test](../assets/order-example/src/test/java/com/example/orders/order/OrderControllerTest.java)

To test a business rejection, send a request that passes MVC binding and validation. Trigger the business condition explicitly and assert the expected error details. Exercise malformed or invalid input in a separate test so an early validation response cannot satisfy the business rejection test.

When a changed input has a limit, test the boundary and the nearest relevant values on either side. Cover omitted, explicit `null`, and empty values separately when the contract distinguishes them.

## Verify list contracts

When introducing or changing pagination, specify the default and maximum page size, the supported public sort fields, and the sort order for ties. Follow the project's policy for oversized pages and unsupported sort fields. Test the limit and a value beyond it, supported and unsupported sort fields, and records with equal primary sort values across a page boundary.

## Verify creation and compatibility

When changing an endpoint, check its HTTP method contract. A read request should leave business state unchanged. Verify with a read before and after the request when the change could affect stored state. For a write that promises idempotency, send the same request twice and assert the final state and relevant durable side effects. Check each response against the contract, which may allow the two responses to differ.

When the project maintains an OpenAPI specification, update affected operations and schemas for any public contract change. Check the changed parameters, request and response bodies, status codes, and error schemas against the verified HTTP behavior. Use the project's existing specification generation or validation workflow when available.

For a new synchronous create endpoint, default to `201 Created`. Include a `Location` if a read endpoint identifies the created resource. Verify that the URL can read back the resource. When adding an optional request field to an existing endpoint, send an old request without that field and assert its existing status and response fields. [HTTP integration test](../assets/order-example/src/test/java/com/example/orders/OrderHttpIT.java)
