# Create a Spring Boot 4 service

## Choose the generation path

| Task | Path |
| --- | --- |
| New Maven service with MVC and validation | Use the bundled generator. Leave `--persistence` at its default, `none`. |
| New Maven service that needs JPA and PostgreSQL | Pass `--persistence jpa-postgresql`. |
| New service that requires a different build tool, version, or stack | Use the matching Spring Initializr options or the project's established scaffolding. With Initializr, check dependency IDs and their compatibility with the selected Spring Boot version before generating. Report the combination generated and checked. |
| Extend an existing service | Use its wrapper, dependency management, and directory structure. Follow the existing-service workflow. [Skill entry point](../SKILL.md#modify-an-existing-service) |

## Run the bundled generator

The generator uses Spring Initializr to create the Maven project and wrapper. Check [versions.json](../versions.json) for the pinned Spring Boot and Java versions and the PostgreSQL image. Use Node.js 22 or later, `unzip`, and a writable parent directory on macOS or Linux. Generation requires network access to Spring Initializr. Building requires the configured JDK and access to Maven artifacts or an existing cache.

From the skill directory, run the generator with a new output path.

```bash
node scripts/create-project.mjs \
	--name orders-api \
	--group-id com.example \
	--output-dir /path/to/orders-api
```

If generation fails, read the generator error and correct the indicated input or prerequisite before retrying. If the destination already exists, choose another path for a new project or use the existing-service workflow.

## Configure PostgreSQL when selected

The PostgreSQL variant adds JPA, Flyway, PostgreSQL, Testcontainers, and a Compose file. Its application test uses a Testcontainers service connection. Start Docker before running the verification command for this variant.

For local startup, export a development `DATABASE_PASSWORD`, run `docker compose up -d`, then run `./mvnw spring-boot:run` in the same environment. Set `DATABASE_URL` and `DATABASE_USER` if the database address or user differs. Add the first Flyway migration when the project has a persisted model. Hibernate validates the resulting schema.

## Verify the generated project

### All Maven skeletons

- Inspect the generated build file and wrapper. Confirm the Boot and Java versions, build tool, and dependencies match the selected path. Use `./mvnw -v` to check the JDK running Maven. If the project uses a toolchain, also verify which JDK compiles the sources.
- If the selected scaffold creates multiple modules, confirm each module is included in the parent build and locate the application entry point in each deployable module.
- From the generated directory, run `./mvnw -B verify`. The MVC skeleton needs no Docker.
- Start the application with `./mvnw spring-boot:run` and check the startup log for the bound port. The skeleton has no business routes until the first feature is added.

### Additional checks for PostgreSQL

- In the verification output, confirm that the container-backed test ran.
- In the startup output, confirm that the application connected to PostgreSQL.

Report the version and options used, the checks that passed, and any missing prerequisite that prevented a check from running.

If startup fails, record the failed phase and the first relevant error and its cause. Use that evidence to distinguish build, configuration, database, migration, and port-binding failures before retrying.

If the project configures a health or readiness probe, call its actual path and port with the credentials used by the probe. Check the expected status after startup, with the required runtime dependencies available.

## Find the checks for an existing project

Read the build configuration and CI commands before selecting a wrapper task. Find the phases or tasks that run formatting checks, architecture tests, integration tests, and coverage checks when the project configures them. Use the command that covers the checks relevant to the change, and verify their results in the build output or test reports.
