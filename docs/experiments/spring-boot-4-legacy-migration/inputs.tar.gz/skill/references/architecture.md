# Organize code and enforce dependencies

## Choose the structure and layers

Inspect adjacent features, build modules, deployment entry points, and architecture tests. Preserve the existing project's organization when adding behavior.

| Dimension | Default for a new service | What to inspect in an existing project |
| --- | --- | --- |
| Code organization | Group by feature. Controllers adapt HTTP, application services implement use cases, and persistence code owns storage mappings. | Adjacent features, including any established ports, adapters, or Spring Modulith boundaries. |
| Dependencies | A controller calls its application service. Each feature owns access to its persistence layer. | Package visibility, published interfaces, and executable dependency rules. |
| Deployment | One Spring Boot application. | Which modules share an entry point and which deploy independently. |

Add an interface or layer when it has a defined job, such as isolating an external adapter or exposing a module boundary. For a simple feature, use the adjacent implementation to decide which layers it needs. Before adding a forwarding type, identify the boundary it owns and the callers that depend on it.

In a project already using Spring Modulith, extend the existing module API or named interface when another module needs access. Run the project's module verification, such as `ApplicationModules.of(Application.class).verify()`, to check for dependency cycles and access to internal packages.

For an existing ports-and-adapters design, express the project's inward dependency rule using its real package names. For example, if `..domain..` owns the domain and `..adapter..` contains the Web and persistence adapters, the domain rule can use `noClasses().that().resideInAPackage("..domain..").should().dependOnClassesThat().resideInAPackage("..adapter..")`. Verify that an adapter calling a domain type passes and that a domain type importing a persistence adapter fails. For simpler feature packages, use the feature boundary described below.

## Call the public API of another feature

**Prefer.** Call the other feature's public application service or module interface and use its public result types. Use package visibility for internal types where possible. If an internal type must be public for another package in its own feature, use a dependency rule to enforce its visibility across features.

**Avoid.** Importing another feature's Repository or persistence entity to reuse a query. This makes the caller depend on the other feature's storage model.

**Verify.** Check that the caller depends only on the other feature's public entry points and result types. Use the dependency rule described below.

## Prove the architecture rule checks the boundary

**Prefer.** Run dependency rules against the actual production packages. Scope each rule to the relevant callers, public entry points, or internal packages. Use the project's existing ArchUnit or Modulith checks when available.

**Avoid.** Treating a passing naming check as proof of a dependency boundary. A correctly named class can still access an internal type. An import scope that omits the caller can also miss the violation.

**Verify.** Exercise the same rule with a caller using the public service and a fixture accessing the repository directly. Confirm the legal caller passes and the failure identifies the forbidden dependency. Include a fixture that references an internal type through a method declared on an inherited interface when that path matters. [Caller fixtures](../assets/order-example/src/test/java/com/example/orders/inventory/InventoryDependencies.java) · [Runnable ArchUnit test](../assets/order-example/src/test/java/com/example/orders/architecture/OrderArchitectureTest.java)

Use a transitive rule only for callers whose policy forbids reachability through intermediate types. The bundled fixture shows a caller passing the direct rule and failing the transitive rule on the same imported classes. Normal feature APIs can delegate to their own internal persistence, so scope a transitive rule to the specific boundary that requires it. [Runnable ArchUnit test](../assets/order-example/src/test/java/com/example/orders/architecture/OrderArchitectureTest.java)
