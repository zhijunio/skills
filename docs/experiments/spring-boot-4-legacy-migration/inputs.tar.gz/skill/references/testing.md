# Verify Spring Boot application behavior

Use the narrowest test that observes the changed behavior. Resolve test starter modules and imports against the project's Boot release and dependency management.

| Behavior | Test |
| --- | --- |
| Business rules independent of Spring | Plain JUnit with domain inputs and results. |
| Application configuration and startup | A startup smoke test that loads the application with representative configuration and any required dependencies. |
| Request binding, validation, and response shape | MVC slice with `@WebMvcTest` and MockMvc. For Boot 4 MVC tests, check the `spring-boot-starter-webmvc-test` dependency. |
| JSON serialization or deserialization in isolation | JSON slice with `@JsonTest`. Use the project's configured mapper and representative payloads. |
| Query behavior, mappings, or database constraints | Persistence test against the matching database engine. Flush before asserting deferred SQL errors. Clear the persistence context for a database read when needed. |
| Schema or data migration | Upgrade test against the matching engine with records created before the migration. |
| An operation crossing MVC, transaction, and database boundaries | Focused application integration test. Use the project's existing database setup or Testcontainers. The bundled order test uses a full application context with MockMvc and PostgreSQL. |
| Behavior that depends on the running server or network | Start the application on a random port and send HTTP requests with a client. Check the behavior that requires the server, such as session cookies or redirects across requests. |
| Code dependency boundaries | Architecture test with production packages and a violating fixture that proves the rule can fail. |

A startup test covers application wiring. An MVC slice covers the HTTP contract within its configured slice. Use the actual security configuration when the behavior depends on filter selection or authentication. Use a real port when the behavior depends on the running server or network. [Bundled MVC slice](../assets/order-example/src/test/java/com/example/orders/order/OrderControllerTest.java) · [Bundled application integration test](../assets/order-example/src/test/java/com/example/orders/OrderHttpIT.java) · [Security filter verification](security.md#verify-the-security-filter-chain)

Map each changed acceptance criterion to an observable assertion. For a stored write, verify the response and the resulting persisted state when both are part of the contract. For a rejected write, verify that the relevant state did not change.

When a Boot 4 test needs to override a bean in the application context, use Spring Framework's `@MockitoBean` or `@MockitoSpyBean` as appropriate. The bundled MVC slice shows a bean override. [MVC slice test](../assets/order-example/src/test/java/com/example/orders/order/OrderControllerTest.java)

## Check an upgrade with existing data

Initialize the database at the previous supported schema version using the project's migration tool. With Flyway, apply migrations up to that version before inserting records that exercise the changed fields or constraints. Run the normal upgrade path. Use the application to verify existing records and new writes, and check the values produced by any backfill.

## Check rollback

**Prefer.** Arrange a fixture where a later write fails at the database after an earlier write succeeds. Invoke the operation through its normal entry point. Read the state in a separate transaction after the operation finishes.

Run application commit and rollback tests without a test-level `@Transactional`. An in-process call can join the test transaction and defer the application's commit. With a real port, the server handles requests in a separate thread and transaction, so commit fixture setup before making the request and clean up committed data separately. A rollback-managed repository slice still works for checks limited to repository behavior.

**Avoid.** Stubbing a repository to throw and using the error response as proof of database rollback. That test can verify error handling, but it never observes a real transaction.

**Verify.** Assert the failure response or exception and verify that the earlier write was undone. For a retryable operation, remove the failure condition and verify that a retry succeeds with the expected stored state.

## Check concurrent writes

**Prefer.** Establish a synchronization point that both requests must reach. For a contested PostgreSQL row, hold its lock in a separate transaction and wait with a deadline for evidence in `pg_stat_activity` that both writes are blocked. Release the lock in cleanup even if the wait fails.

**Avoid.** Launching two async requests and assuming they overlapped. A fixed sleep cannot prove that either request reached the critical operation.

**Verify.** Check each response and the final stored state against the operation's contract after observing the overlap.

This skeleton assumes an isolated PostgreSQL fixture. The helpers acquire the target row lock and count the matching write statements that are waiting on a database lock. Use a separate connection to query the wait state.

```java
try (var blocker = dataSource.getConnection()) {
	blocker.setAutoCommit(false);
	lockTargetRow(blocker, id);
	var first = sendWriteAsync(id);
	var second = sendWriteAsync(id);
	try {
		await().atMost(Duration.ofSeconds(8))
				.until(() -> countWaitingWrites() >= 2);
	}
	finally {
		blocker.rollback();
	}
	assertOutcomes(first.get(10, TimeUnit.SECONDS), second.get(10, TimeUnit.SECONDS));
}
assertFinalState(id);
```

## Prepare and isolate test data

Create fixtures through the public API or service when setup should follow business rules. Use SQL when an upgrade, constraint, or simulated failure requires a specific database state. Give each test isolated records or reset the affected state. Remove temporary constraints and release locks in cleanup. Verify that a case gives the same result alone and in the suite.

Unique fixture IDs isolate tests whose queries use those IDs. For unscoped lists, totals, or rules spanning records, isolate the queried dataset or reset it between tests.

## Connect test services and run checks

Use `@ServiceConnection` when Boot supports the container's connection details. Register dynamic external URLs or ports using the project's configuration mechanism, such as `@DynamicPropertySource`. Put static test settings in test configuration. Use mapped ports assigned by the runtime to avoid collisions.

To verify database-specific SQL, constraints, or locks, use the target database engine. An in-memory substitute cannot establish that behavior for a different engine.

If Spring test startup becomes a bottleneck, inspect which tests create distinct contexts. Reuse equivalent profiles, bean overrides, and configuration where the tests need the same setup. Reserve `@DirtiesContext` for tests that actually invalidate their context. Check the reports after reorganizing tests to confirm the expected cases still run.

Run the project's wrapper and the task that includes the relevant tests. Inspect the build configuration and test reports to confirm the expected suites ran. In the bundled example, `./mvnw -B test` runs the MVC and architecture tests. `./mvnw -B verify` with Docker also runs the PostgreSQL integration test through Failsafe. Report which checks passed or failed, which tests the runner skipped, and which checks did not execute. Include the reason for any skip or missing prerequisite. [Runnable example](../assets/order-example/README.md)
