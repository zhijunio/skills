# Implement JPA persistence

Confirm the project's provider, database engine, and schema management before changing a mapping. In the generated PostgreSQL project, Flyway owns schema changes and Hibernate uses `ddl-auto=validate`. Follow the existing project's ID and mapping conventions.

## Map entities and relationships

Give each JPA entity a public or protected no-argument constructor. Use a separate constructor or factory for required business inputs. Preserve existing ID types, generation strategies, column mappings, and enum representations. For a new enum column without a project convention, prefer explicit string mapping and plan a data migration when a stored name changes. [Bundled entity](../assets/order-example/src/main/java/com/example/orders/order/persistence/OrderEntity.java)

**Prefer.** Identify which records the entity owns before choosing cascade options. For a parent that owns the full lifecycle of its children, use only the cascade operations required by the relationship. Enable orphan removal when removing a child from that relationship should delete its row.

**Avoid.** Adding `CascadeType.ALL` to a reference to an independently managed entity to make a save succeed. The mapping could also cascade a delete to a record shared by other entities.

**Verify.** Flush and clear the persistence context, then read the database state after adding or removing a child. Verify that the operation preserves independently managed references.

## Set the transaction boundary

Put writes that must commit together in one application operation. Ensure Spring applies the transaction at the operation's entry point. With proxy-based transactions, a same-bean call bypasses the proxy. Let failures that require rollback propagate across the boundary, and check the rollback rules if the operation uses checked exceptions. Verify atomicity with a real failure after an earlier write succeeds. [Rollback test guidance](testing.md#check-rollback)

## Enforce uniqueness in the database

**Prefer.** Add a named database constraint for values that must be unique under concurrent writes. If the API promises a conflict response, identify that constraint before translating the failure. For an immediate constraint, flush within the service's `try` block when it needs to catch a failure from a pending insert. Let unrelated failures follow the project's error policy. [Order migration](../assets/order-example/src/main/resources/db/migration/V1__create_orders.sql) · [Order service](../assets/order-example/src/main/java/com/example/orders/order/OrderService.java)

**Avoid.** Using `existsBy…` followed by `save` as the sole uniqueness check. Two transactions can both see the value as available.

**Verify.** Submit a duplicate write against the project's database engine. Check the expected error and verify that only one record exists. [HTTP integration example](../assets/order-example/src/test/java/com/example/orders/OrderHttpIT.java)

## Choose concurrency control

| Condition | Implementation |
| --- | --- |
| The database can check the precondition on one row | Put the condition in the update's `WHERE` clause. Use the affected row count to decide whether to continue. Handle a zero-row update according to the operation's contract. |
| The operation reads state first and can handle stale writes | Use the project's optimistic locking convention, typically `@Version`. Handle the stale write explicitly. Retry only when rerunning the entire operation fits its contract. |
| The operation must read current state while excluding a concurrent writer | Use a row lock in a short transaction. If several rows must be locked, take locks in a consistent order. |

### Single-row precondition example

**Prefer.** For a simple claim operation, update the row with a predicate such as `WHERE id = :id AND state = 'READY'`. Run dependent writes in the same transaction only when the update claims the row. Bulk JPQL updates bypass managed entities. Reload before reading changed fields, or carry forward values that the update does not change.

**Avoid.** Reading `READY` and then writing the new state without a version check, row lock, or update predicate. Two transactions can both read `READY` and perform the dependent writes.

The following excerpts assume a string-valued job state and omit the enclosing repository and service declarations. An unsuccessful claim leaves the data unchanged.

```java
@Modifying
@Query("update Job j set j.state = 'CLAIMED' where j.id = :id and j.state = 'READY'")
int claimIfReady(@Param("id") long id);

@Transactional
public void claim(long id) {
	if (jobs.claimIfReady(id) == 1) {
		claims.save(new Claim(id));
	}
}
```

The unguarded version below allows two callers to pass the same state check before either writes. This example assumes the job has no version check or lock.

```java
var job = jobs.findById(id).orElseThrow();
if (job.isReady()) {
	job.markClaimed();
	claims.save(new Claim(id));
}
```

**Verify.** Observe overlapping transactions and check each result alongside the final stored state. [Concurrency test guidance](testing.md#check-concurrent-writes)

## Bind values in custom queries

Bind external values as parameters in JPQL and native SQL. For example, use `where o.orderNumber = :orderNumber` with a bound value. When a caller can choose a column or sort direction, map the supported public options to fixed query expressions. Reject or handle unsupported options according to the API contract. Verify that values containing quotes are treated as data and that unsupported sort keys follow the expected error or fallback path.

## Load the data the operation needs

Choose a projection or fetch plan based on the fields and associations the operation uses. Preserve existing pagination and sorting conventions. Avoid changing all associations to eager loading to address a query-specific N+1. When addressing N+1, run the query with several parent records and inspect whether statement count grows with the result size.

When Open Session in View is disabled, fetch the data the response needs and map it to a DTO inside the application operation. For example, load parents and their required details with a projection or a targeted fetch plan, then return the DTOs after the transaction closes. Exercise the normal HTTP path with several parents and nonempty associations and assert that the expected detail fields are present.

For a page of parent records with a to-many association, consider paging parent IDs first and fetching the associated data for those IDs separately. A collection fetch join can multiply rows and interfere with database pagination. Verify the generated SQL, page size, and parent order against the target database. For a new cursor query, include a unique tie-breaker in both the sort and cursor predicate. Test records with equal primary sort values on either side of a page boundary to catch omissions and duplicates.

## Verify migrations with existing rows

Check how existing rows satisfy new defaults and constraints. Backfill rows when needed before enforcing the new constraint. Verify from the previous supported schema with representative records. [Upgrade test guidance](testing.md#check-an-upgrade-with-existing-data)

Keep Flyway versioned migrations applied in shared environments intact. Correct them with a new versioned migration so instances retain the same migration history and checksums.

When old and new application versions can run against the same database, add compatible schema changes first. Backfill existing data as needed, and remove the old schema only after the old application version no longer uses it. Verify reads and writes from both versions against the intermediate schema before removing anything.

For a large table or a migration with a tight downtime budget, identify the target database engine and version, table size, expected locks, and whether the statement scans or rewrites the table. Decide whether a backfill needs batches or a separate rollout step. Plan how to observe progress, when to stop the rollout, and how to resume safely. Test with representative data and traffic before drawing conclusions about production lock duration.
