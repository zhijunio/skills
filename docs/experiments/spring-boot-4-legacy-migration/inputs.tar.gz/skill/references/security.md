# Extend application authorization

Inspect the existing security filter chains, method authorization, and representative tests before adding an endpoint. Identify the authenticated principal, the rules that apply to the operation, and how the project reports authentication and authorization failures.

## Derive caller identity from authentication

**Prefer.** Use the principal or caller context established by the project's authentication mechanism. Resolve tenant membership using the project's trusted identity and membership rules. A user ID or tenant ID from the request can identify a target, subject to those rules.

**Avoid.** Treating a path parameter, request field, or unverified header as proof of the caller's identity or tenant membership. A caller can supply a different value.

**Verify.** Authenticate as one caller and change the target identifier in the request. Confirm the supplied value cannot grant access outside the caller's authorized scope.

## Authorize access to the resource

**Prefer.** Apply the project's role policy and any ownership or tenant policy to the application operation. For a write, enforce resource authorization before changing stored state. Scope lookups, lists, and bulk operations to the resources the caller may access. Apply the project's policy for a bulk request that includes a resource outside that scope.

**Avoid.** Assuming that a role granting access to an endpoint also grants access to every record accepted by the endpoint. Two callers can have the same role and different resource permissions.

For an endpoint that restricts edits to owners, the controller or existing security policy first checks the editor role. The operation then uses the authenticated principal to restrict the write. This fragment assumes the application authenticates the caller before invoking the operation.

```java
if (!documents.archiveIfOwned(id, caller.getName())) {
	throw new ResponseStatusException(HttpStatus.NOT_FOUND);
}
```

For a database-backed operation, `archiveIfOwned` can restrict the update by both resource ID and owner. The example uses `404` for records outside the caller's scope. A role check followed by `documents.archive(id)` would leave the write unrestricted by owner.

**Verify.**

- Cover an allowed caller, an anonymous caller, a caller with insufficient privileges, and a caller with the correct role but the wrong owner or tenant when applicable. Follow the project's response policy, including whether it conceals out-of-scope resources with `404`.
- After a denied write, read back the stored state and confirm it is unchanged.
- For list or bulk operations, include records from different owners or tenants. Assert the results or changes allowed by the policy.

The runnable MVC fixture supplies two authenticated principals with the same role. It checks that the denied write leaves the record unchanged and that the owner can archive it. The fixture supplies the principal and role directly so the test focuses on resource authorization. [Resource authorization test](../assets/order-example/src/test/java/com/example/orders/authorization/ResourceAuthorizationTest.java)

## Verify the security filter chain

When a change affects request authorization or chain selection, run a request-level test with the project's actual security configuration and filters. Check the chain matchers, their order, and the rules for the HTTP methods affected by the change.

- Exercise the changed path and method as an anonymous caller, an authorized caller, and an authenticated caller without the required authority. Assert the configured outcomes, including a challenge or redirect when the application uses one.
- If multiple chains apply, exercise a neighboring path or method with a different expected policy. Check an observable outcome that would differ if the wrong chain handled the request.
- To verify authentication itself, submit credentials through the application's configured mechanism. A fixture that injects a principal is appropriate for isolating resource authorization. Use separate requests through the authentication mechanism to verify credential handling.

The bundled test uses a test-only HTTP Basic configuration with real Spring Security filters. It sends requests without credentials, with a valid account lacking the required role, and with an authorized account. The assertions verify the challenge, denial, and controller response. Run it with `./mvnw -B -Dtest=SecurityFilterChainTest test` from the bundled order example. [Security filter chain test](../assets/order-example/src/test/java/com/example/orders/authorization/SecurityFilterChainTest.java)

## Verify CSRF based on how credentials are sent

Keep CSRF protection for browser requests when the browser automatically supplies credentials, such as a session cookie. For a state-changing operation, test that the configured chain rejects a request without a valid token and lets an otherwise authorized request with a valid token reach the operation.

A chain that exclusively accepts bearer tokens sent explicitly in the `Authorization` header can use a different CSRF policy. Confirm it does not also accept browser-supplied credentials. When the application has both kinds of chains, exercise a representative write in each chain and verify its own policy.

## Verify CORS for cross-origin browser clients

When the application serves cross-origin browser clients, use the project's configured origins, methods, headers, and credential policy. Test an allowed preflight with the intended origin, method, and request headers. Assert the relevant CORS response headers, including credentials when required. Test an unapproved origin and confirm the response grants it no cross-origin access. Check CORS separately from request authorization and CSRF.
